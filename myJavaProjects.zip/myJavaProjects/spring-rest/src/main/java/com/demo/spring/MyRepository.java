/*package com.demo.spring;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface MyRepository extends CrudRepository<Emp, Integer> {
    @Query("select e from Emp e where e.salary>50000")
	public List<Emp> getALLEmp5000();
}*/
