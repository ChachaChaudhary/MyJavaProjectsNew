package com.demo.spring;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
   ApplicationContext ctx= new ClassPathXmlApplicationContext("context.xml");
   Mail mail=(Mail) ctx.getBean("mail");
    System.out.println(mail.getMessage().getBody());
    List<String>lists=(List<String>) ctx.getBean("list");
    System.out.println(lists);
    }
}
