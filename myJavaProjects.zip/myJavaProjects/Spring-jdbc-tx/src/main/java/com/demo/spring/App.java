package com.demo.spring;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfiguration.class);
		JdbcTemplate jt = (JdbcTemplate) ctx.getBean("jdbcTemplate");
		Dao dao= (Dao)ctx.getBean("daoImpl");
		List<Emp> empList= new ArrayList<>();
		empList.add(new Emp(2037,"Ratan","Pune",30000));
		empList.add(new Emp(2028,"Chetan","Pune",30000));
		empList.add(new Emp(2409,"Ketan","Pune",30000));
		empList.add(new Emp(1305,"Jiten","Pune",30000));
		empList.add(new Emp(2141,"Kitten","Pune",30000));
		try{
		dao.save(empList);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
		List <String> empLister = jt.query("select * from emp", new RowMapper<String>(){
			@Override
			public String mapRow(ResultSet rs, int arg1) throws SQLException{
				 return rs.getString("empno");
			}
		});
		empLister.forEach(name-> System.out.println(name));
		}
		}
}
