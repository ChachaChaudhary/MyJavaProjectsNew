package com.demo.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import com.demo.jpa.AppConfiguration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfiguration.class);
		EntityManagerFactory ls =(EntityManagerFactory)ctx.getBean("entityManagerFactory");
	//	EntityManagerFactory emf = ls.getObject();
		EntityManager em = ls.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		try {
			tx.begin();
			Dept dept = (Dept) em.find(Dept.class, 2007);
		    Emp e1 = new Emp(206, "Ankit", "Hyderabad", 50000);
			Emp e2 = new Emp(207, "Shekhar", "bangalore", 52000);
			e1.setDept(dept);
			e2.setDept(dept);
			em.persist(e1);
			em.persist(e2);
			tx.commit();

		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}
    }
}
