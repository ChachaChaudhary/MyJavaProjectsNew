package com.demo.spring;


import java.util.logging.Logger;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class Mylogger {
Logger logger=Logger.getLogger("demo");
	public Mylogger() {
		// TODO Auto-generated constructor stub
	}
@Around("execution(* com.demo.spring.WriterApp.*(..))")
	public Object log(ProceedingJoinPoint pjp) throws Throwable{
	 logger.info("Before doConcat method call..");
	 Object retVal=pjp.proceed();
	 logger.info("After doConcat method call..");
	 return retVal;
}

}
