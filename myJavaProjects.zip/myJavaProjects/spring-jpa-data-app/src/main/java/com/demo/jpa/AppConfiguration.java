package com.demo.jpa;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@ComponentScan(basePackages=("com.demo.jpa"))
@EnableJpaRepositories(basePackages=("com.demo.jpa"))
@EnableTransactionManagement
public class AppConfiguration {

	public AppConfiguration() {
		// TODO Auto-generated constructor stub
	}
	@Bean
	 public DataSource ds(){
		 DriverManagerDataSource ds = new DriverManagerDataSource();
		 ds.setDriverClassName("com.mysql.jdbc.Driver");
		 ds.setUrl("jdbc:mysql://localhost:3306/demo2");
		 ds.setUsername("root");
		 ds.setPassword("admin");
return ds;
	 }
	@Bean
	 public LocalContainerEntityManagerFactoryBean entityManagerFactory(){
	  LocalContainerEntityManagerFactoryBean localContainerEntityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
	  localContainerEntityManagerFactoryBean.setDataSource(ds());
      HibernateJpaVendorAdapter jva = new HibernateJpaVendorAdapter();
      jva.setDatabase(Database.MYSQL);
      jva.setShowSql(true);
      localContainerEntityManagerFactoryBean.setJpaVendorAdapter(jva);
      return localContainerEntityManagerFactoryBean;
	}
	@Bean
	public JpaTransactionManager transactionManager(){
		JpaTransactionManager tManager = new JpaTransactionManager();
		tManager.setEntityManagerFactory(entityManagerFactory().getObject());
		return tManager;
	}
}
