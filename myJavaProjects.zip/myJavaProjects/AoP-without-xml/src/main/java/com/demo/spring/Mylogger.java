package com.demo.spring;


import java.util.logging.Logger;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class Mylogger {
Logger logger=Logger.getLogger("demo");
	public Mylogger() {
		// TODO Auto-generated constructor stub
	}
	@Before("execution(* com.demo.spring.WriterApp.*(..))")
 public void logBefore(){
	 logger.info("Before doConcat method call..");
 }
	@AfterReturning("execution(* com.demo.spring.WriterApp.*(..))")
 public void logAfter(){
	 logger.info("After doConcat method call..");
 }
}
