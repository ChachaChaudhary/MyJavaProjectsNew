package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class WriterApp {
	
@Autowired	
Writer writer;
	public WriterApp() {
		// TODO Auto-generated constructor stub
	}
	public void print(String message){
		System.out.println(writer.write(message));
	}
	public void printOneMore(String message){
		System.out.println(writer.write(message+" More"));
	}
	public String doConCat(String message){
		return (writer.write(message+" More"));
	}

}
