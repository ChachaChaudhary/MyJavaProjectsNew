package com.demo.spring;

public interface Writer {
 public String write (String s);
}
