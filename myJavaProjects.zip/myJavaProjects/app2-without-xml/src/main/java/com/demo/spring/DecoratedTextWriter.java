package com.demo.spring;

import org.springframework.stereotype.Component;

//@Component
public class DecoratedTextWriter implements Writer {

	public DecoratedTextWriter() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String write(String s) {
		return "Decorated Text Writer : "+s;
	}

}
